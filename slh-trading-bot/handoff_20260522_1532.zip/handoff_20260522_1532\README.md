# SLH Agent Handoff Package
Generated: 05/22/2026 15:32:27

This package contains the current state of the SLH Trading Bot project.
Please review TASKS.md for remaining tasks.

## Quick Start
- Run .\slh-start-all.ps1 to start all services.
- Open http://localhost:3000 for the dashboard.
- Use @SLH_Supervisor_bot on Telegram for commands.

## Files included
TASKS.md
docs\slh-ui-plan.md
docs\slh-project-management.md
core\rbac_engine.py
SLH_JOURNAL.md
main_live.py
supervisor_agent.py
main_telegram.py
docker-compose.yml
Dockerfile
requirements.txt
start_ngrok.ps1
slh-doctor.ps1
slh-help.ps1
slh-start-all.ps1
slh-full-report.ps1
