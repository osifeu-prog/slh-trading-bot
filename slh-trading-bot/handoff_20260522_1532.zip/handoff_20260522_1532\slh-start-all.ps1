Write-Host "Starting all SLH services..." -ForegroundColor Cyan
Set-Location "C:\Users\USER\Desktop\SLH\algo-bot"
docker-compose up -d
Start-Sleep -Seconds 15
Start-Process -NoNewWindow -FilePath ".\venv\Scripts\python.exe" -ArgumentList "supervisor_agent.py"
Start-Sleep -Seconds 3
Start-Process -NoNewWindow -FilePath ".\venv\Scripts\python.exe" -ArgumentList "main_telegram.py"
Start-Sleep -Seconds 3
Set-Location "C:\Users\USER\Desktop\SLH\frontend"
Start-Process npm -ArgumentList "run dev" -WindowStyle Minimized
Write-Host "? All SLH services started." -ForegroundColor Green
